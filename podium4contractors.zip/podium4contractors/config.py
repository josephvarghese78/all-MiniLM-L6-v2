qe_resources=[
  "Akshay Kuryalkar",
  "Anju Sasidharan",
  "Habibur Rahaman",
  "Nandhakumar Subramani",
  "Nishanth Selvakumar",
  "Patapati Druthi",
  "Rashi Jain",
  "Satrajit Dey",
  "Satyajeet Dutta",
  "Shilpi Wadhwani",
  "Umaparvathi Kadimisetty",
  "Veera Yaswanth Satyanarayana",
  "Venkatesan Ananthanarayanan",
  "Yuvaraj Vijayakumar",
  "Marco Flores"
]

qe_manager="Joseph Varghese"

template="classic"