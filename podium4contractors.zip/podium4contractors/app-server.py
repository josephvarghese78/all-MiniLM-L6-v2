import http.server
import urllib.parse
import os
from string import Template
from datetime import datetime
import config as cfg

today = datetime.now()
formatted_today = today.strftime('%B %d, %Y')

PORT = 8080

#
resource_options_html = "".join([f'<label class="custom-option"><input type="checkbox" name="qeresource" value="{name}" onclick="event.stopPropagation(); updateSelection()">{name}</label>' for name in cfg.qe_resources])

FORM_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recognition Card</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f4f5f7; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }}
        .form-container {{ background: #fff; padding: 50px; border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,0.08); width: 650px; }}
        h2 {{ margin-bottom: 30px; font-size: 26px; color: #2d3748; text-align: center; }}
        label {{ display: block; margin-bottom: 10px; font-weight: 600; font-size: 15px; color: #4a5568; }}
        select, input, textarea {{ width: 100%; padding: 14px; margin-bottom: 24px; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 15px; box-sizing: border-box; background: #fff; }}
        textarea {{ resize: vertical; height: 160px; }}
        
        /* Custom Beautiful Multi-Select Styling */
        .custom-select-wrapper {{ position: relative; margin-bottom: 24px; }}
        .select-trigger {{ width: 100%; padding: 14px; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 15px; background: #fff; cursor: pointer; display: flex; justify-content: space-between; align-items: center; box-sizing: border-box; color: #2d3748; user-select: none; }}
        .select-trigger:hover {{ border-color: #a0aec0; }}
        .arrow {{ border: solid #4a5568; border-width: 0 2px 2px 0; display: inline-block; padding: 4px; transform: rotate(45deg); transition: transform 0.2s ease; }}
        .custom-select-wrapper.open .arrow {{ transform: rotate(-135deg); }}
        
        .custom-options {{ position: absolute; top: 100%; left: 0; right: 0; background: #fff; border: 1px solid #cbd5e0; border-radius: 6px; box-shadow: 0 6px 16px rgba(0,0,0,0.1); margin-top: 4px; display: none; z-index: 10; max-height: 220px; overflow-y: auto; }}
        .custom-select-wrapper.open .custom-options {{ display: block; }}
        .custom-option {{ padding: 12px 16px; cursor: pointer; display: flex; align-items: center; gap: 10px; font-size: 14.5px; color: #2d3748; transition: background 0.15s; }}
        .custom-option:hover {{ background: #f7fafc; }}
        .custom-option input[type="checkbox"] {{ width: 18px; height: 18px; accent-color: #1a7f41; cursor: pointer; margin: 0; }}

        button {{ width: 100%; background: #1a7f41; color: white; border: none; padding: 16px; font-size: 17px; font-weight: 600; border-radius: 6px; cursor: pointer; }}
        button:hover {{ background: #156533; }}
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Recognition Card Generator</h2>
        <form method="POST" action="/">
            <label>Select Theme</label>
            <select id="template" name="template">
                <option value="classic">Classic</option>
                <option value="modern">Modern</option>
            </select>
            <label>Select Manulife Value</label>
            <select id="mlvalue" name="mlvalue">
                <option value="Obsess about customers">Obsess about customers</option>
                <option value="Do the right thing">Do the right thing</option>
                <option value="Get it done together">Get it done together</option>
                <option value="Own it">Own it</option>
                <option value="Share your humanity">Share your humanity</option>
            </select>
            
            <label for="resource_name">Quailty Engineer Name(s)</label>
            <div class="custom-select-wrapper" id="customSelect">
                <div class="select-trigger" onclick="toggleDropdown(event)">
                    <span id="selectedLabel">Select QE(s)...</span>
                    <span class="arrow"></span>
                </div>
                <div class="custom-options">
                    {resource_options_html}
                </div>
            </div>

            <label for="title">Title</label>
            <input type="text" id="title" name="title" placeholder="Enter card title..." required>

            <label for="feedback">Feedback</label>
            <textarea id="feedback" name="feedback" placeholder="Enter recognition feedback..." required></textarea>

            <button type="submit">Generate Card</button>
        </form>
    </div>

    <script>
        function toggleDropdown(e) {{
            e.stopPropagation();
            document.getElementById('customSelect').classList.toggle('open');
        }}

        function updateSelection() {{
            const checkboxes = document.querySelectorAll('input[name="qeresource"]:checked');
            const label = document.getElementById('selectedLabel');
            if (checkboxes.length === 0) {{
                label.textContent = "Select QE(s)...";
                label.style.color = "#a0aec0";
            }} else if (checkboxes.length === 1) {{
                label.textContent = checkboxes[0].value;
                label.style.color = "#2d3748";
            }} else {{
                const values = Array.from(checkboxes).map(cb => cb.value);
                label.textContent = values.join(', ');
                label.style.color = "#2d3748";
            }}
        }}

        // Close dropdown when clicking outside
        //window.addEventListener('DOMContentLoaded', updateSelection);
        window.addEventListener('pageshow', updateSelection);
        window.addEventListener('click', function() {{
            document.getElementById('customSelect').classList.remove('open');
        }});
    </script>
</body>
</html>
"""


class RecognitionHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Serve the form on root GET request, otherwise let it serve static files like images
        if self.path == '/' or self.path == '':
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(FORM_HTML.encode("utf-8"))
        else:
            super().do_GET()

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = urllib.parse.parse_qs(post_data)

        # Get selected template value from dropdown
        selected_template = params.get('template', ['classic'])[0]

        selected_mlvalue = params.get('mlvalue', ['Obsess about customers'])[0]

        # Map dropdown selections to their respective HTML template filenames
        ml_values = {
            "Obsess about customers": "obsessaboutcustomners.html",
            "Think big": "thinkbig.html",
            "Do the right thing": "dotherightthing.html",
            "Get it done together":"getitdonetogether.html",
            "Own it":"ownit.html",
            "Share your humanity":"shareyourhumanity.html"
        }

        # Dynamically determine the filename and build path inside 'templates' folder
        filename = ml_values.get(selected_mlvalue, "obsessaboutcustomners.html")

        if selected_template=="classic":
            template_path = os.path.join("./templates/classic", filename)
        elif selected_template=="modern":
            template_path = os.path.join("./templates/modern", filename)
        else:
            template_path = os.path.join("./templates/classic", filename)

        resource_names=params.get('qeresource', ['Team Member'])

        if len(resource_names)==1:
            resource_name=resource_names[0]
        else:
            resource_name=", ".join(resource_names[:-1]) + f" and {resource_names[-1]}"

        context = {
            "template_name": selected_template,
            "manager_name": cfg.qe_manager,
            "resource_name": resource_name,
            "title": params.get('title', [''])[0],
            "feedback": params.get('feedback', [''])[0],
            "date": formatted_today
        }

        if os.path.exists(template_path):
            with open(template_path, "r", encoding="utf-8") as f:
                raw_html = f.read()

            t = Template(raw_html)
            html_content = t.safe_substitute(context)
        else:
            html_content = f"<h3>Error: Template file '{template_path}' not found in directory.</h3>"

        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html_content.encode("utf-8"))


if __name__ == "__main__":
    server_address = ('', PORT)
    httpd = http.server.HTTPServer(server_address, RecognitionHandler)
    print(f"Server started at http://localhost:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()