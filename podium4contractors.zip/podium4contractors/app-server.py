import http.server
import urllib.parse
import os
from string import Template
from datetime import datetime
import config as cfg

today = datetime.now()
formatted_today = today.strftime('%B %d, %Y')

PORT = 8080

resource_options_html = "".join([f'<option value="{name}">{name}</option>' for name in cfg.qe_resources])

FORM_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Recognition Card Generator</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f4f5f7; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }}
        .form-container {{ background: #fff; padding: 50px; border-radius: 10px; box-shadow: 0 6px 20px rgba(0,0,0,0.08); width: 650px; }}
        h2 {{ margin-bottom: 30px; font-size: 26px; color: #2d3748; text-align: center; }}
        label {{display: block; margin-bottom: 10px; font-weight: 600; font-size: 15px; color: #4a5568; }}
        select, input, textarea {{ width: 100%; padding: 14px; margin-bottom: 24px; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 15px; box-sizing: border-box; }}
        textarea {{ resize: vertical; height: 160px; }}
        button {{ width: 100%; background: #1a7f41; color: white; border: none; padding: 16px; font-size: 17px; font-weight: 600; border-radius: 6px; cursor: pointer; }}
        button:hover {{ background: #156533; }}
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Recognition Card Generator</h2>
        <form method="POST" action="/">
            <label for="template">Select Template</label>
            <select id="template" name="template">
                <option value="classic">Classic</option>
                <option value="modern">Modern</option>
            </select>
            <label for="mlvalue">Select Manulife Value</label>
            <select id="mlvalue" name="mlvalue">
                <option value="Obsess about customers">Obsess about customers</option>
                <option value="Do the right thing">Do the right thing</option>
                <option value="Get it done together">Get it done together</option>
                <option value="Own it">Own it</option>
                <option value="Share your humanity">Share your humanity</option>
            </select>

            <label for="resource_name">Team Member Name</label>
            <select id="resource_name" name="resource_name">
                {resource_options_html}
            </select>

            <label for="title">Title</label>
            <input type="text" id="title" name="title" placeholder="Enter card title..." required>

            <label for="feedback">Feedback</label>
            <textarea id="feedback" name="feedback" placeholder="Enter recognition feedback..." required></textarea>

            <button type="submit">Generate Card</button>
        </form>
    </div>
</body>
</html>
"""


class RecognitionHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        # Serve the form on root GET request, otherwise let it serve static files like images
        if self.path == '/' or self.path == '':
            self.send_response(200)
            self.send_header("Content-type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(FORM_HTML.encode("utf-8"))
        else:
            super().do_GET()

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        post_data = self.rfile.read(content_length).decode('utf-8')
        params = urllib.parse.parse_qs(post_data)

        # Get selected template value from dropdown
        selected_template = params.get('template', ['classic'])[0]

        selected_mlvalue = params.get('mlvalue', ['Obsess about customers'])[0]

        # Map dropdown selections to their respective HTML template filenames
        ml_values = {
            "Obsess about customers": "obsessaboutcustomners.html",
            "Think big": "thinkbig.html",
            "Do the right thing": "dotherightthing.html",
            "Get it done together":"getitdonetogether.html",
            "Own it":"ownit.html",
            "Share your humanity":"shareyourhumanity.html"
        }

        # Dynamically determine the filename and build path inside 'templates' folder
        filename = ml_values.get(selected_mlvalue, "obsessaboutcustomners.html")

        if selected_template=="classic":
            template_path = os.path.join("templates\\classic", filename)
        elif selected_template=="modern":
            template_path = os.path.join("templates\\modern", filename)
        else:
            template_path = os.path.join("templates\\classic", filename)

        context = {
            "template_name": selected_template,
            "manager_name": cfg.qe_manager,
            "resource_name": params.get('resource_name', ['Team Member'])[0],
            "title": params.get('title', [''])[0],
            "feedback": params.get('feedback', [''])[0],
            "date": formatted_today
        }

        if os.path.exists(template_path):
            with open(template_path, "r", encoding="utf-8") as f:
                raw_html = f.read()

            t = Template(raw_html)
            html_content = t.safe_substitute(context)
        else:
            html_content = f"<h3>Error: Template file '{template_path}' not found in directory.</h3>"

        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html_content.encode("utf-8"))


if __name__ == "__main__":
    server_address = ('', PORT)
    httpd = http.server.HTTPServer(server_address, RecognitionHandler)
    print(f"Server started at http://localhost:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()