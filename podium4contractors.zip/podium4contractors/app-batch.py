import random
import json
import config as cfg
from datetime import datetime

today = datetime.now()
formatted_today = today.strftime('%B %d, %Y')
mlvalues=["dotherightthing.html", "getitdonetogether.html", "obsessaboutcustomners.html", "ownit.html", "shareyourhumanity.html", "thinkbig.html"]
manager=cfg.qe_manager
template=cfg.template

if len(manager)==0:
    manager=input("Enter Manager name: ")

if len(template)==0:
    template=input("Enter template number: \n 1. Classic \n 2. Modern\n Enter choice 1 or 2 only: ")
    if template not in ['1', '2']:
        template="classic"
    elif template =='1':
        template="classic"
    elif template =='2':
        template="modern"

with open("./batch1.json", "r") as f:
    feedbacks = json.load(f)


for fb in feedbacks:

    mlvalue=random.choice(mlvalues)
    print(fb['name'], template)
    with open(f"./templates/{template}/{mlvalue}" ,"r") as f:
        filedata=f.read()

    filedata = (
        filedata.replace("$manager_name", manager)
        .replace("$resource_name", fb['name'])
        .replace("$date", formatted_today)
        .replace("$title", fb["title"])
        .replace("$feedback", fb["txt"])
    )

    output_path = f"./output-b/feedback_{fb['name'].replace(' ', '_')}.html"
    with open(output_path, "w") as f:
        f.write(filedata)
